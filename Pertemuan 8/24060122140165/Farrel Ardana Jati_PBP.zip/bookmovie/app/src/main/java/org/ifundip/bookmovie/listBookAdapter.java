package org.ifundip.bookmovie;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import java.util.ArrayList;

public class listBookAdapter extends
        RecyclerView.Adapter<ListViewHolder> {
    ArrayList<book> listMovies;
    public listBookAdapter(ArrayList<book> list){
        this.listMovies= list;
    }
    @NonNull
    @Override
    public ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view=
                LayoutInflater.from(parent.getContext()).inflate(R.layout.item_book,
                        parent,false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ListViewHolder holder, int position) {
        book book=listMovies.get(position);
        Glide.with(holder.itemView.getContext())
                .load(book.getPosterImage())
                .into(holder.ivMoviePoster);
        holder.tvMovieTitle.setText(book.getTitle());
        holder.tvMovieDescription.setText(book.getDescription());

        holder.itemView.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view) {
                Toast.makeText(holder.itemView.getContext(), book.getTitle(),Toast.LENGTH_SHORT).show();
            }

        });
    }

    @Override
    public int getItemCount() {
        return listMovies.size();
    }
};



