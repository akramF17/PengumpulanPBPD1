package org.ifundip.bookmovie;

import android.graphics.Movie;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private final ArrayList<book> listMovies=new ArrayList<>();
 @Override
 protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listMovies.addAll(bukudata.getMovies());
     RecyclerView rvMovies = findViewById(R.id.rv_movies);
        rvMovies.setHasFixedSize(true);
        rvMovies.setLayoutManager(new LinearLayoutManager(this));
        listBookAdapter listMovieAdapter=new
                listBookAdapter(listMovies);
        rvMovies.setAdapter(listMovieAdapter);
    }
}