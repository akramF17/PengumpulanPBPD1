package org.ifundip.bookmovie;

import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class ListViewHolder extends RecyclerView.ViewHolder{
         ImageView ivMoviePoster;
         TextView tvMovieTitle,tvMovieDescription;
         public ListViewHolder(@NonNull View itemView) {
             super(itemView);
             ivMoviePoster= itemView.findViewById(R.id.iv_movie_poster);
             tvMovieTitle= itemView.findViewById(R.id.tv_movie_title);
             tvMovieDescription=itemView.findViewById(R.id.tv_movie_description);
         }
    }
