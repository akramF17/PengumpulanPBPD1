package org.ifundip.bookmovie;


import android.graphics.Movie;

import java.util.ArrayList;

public class bukudata {
    private static final String[] movieTitles = {
            "Tere Liye : Bumi"};


    private static final String[] movieDescriptions = {
            "Raib, seorang remaja biasa, memiliki kemampuan unik untuk menghilang. Kemampuan ini telah ia miliki sejak kecil, tetapi dirahasiakan dari semua orang, termasuk keluarganya. Suatu hari, sebuah kejadian tak terduga di sekolah mempertemukannya dengan Seli, teman sekelas yang ternyata juga memiliki kekuatan luar biasa, yaitu mengeluarkan petir dari tangannya. Keduanya segera bertemu dengan Ali, seorang jenius yang cerdas dan selalu penasaran dengan hal-hal aneh.",
    };

    private static final int[] moviePosterImages = {
            R.drawable.tereliye,

    };

    static ArrayList<book> getMovies() {
        ArrayList<book> movies = new ArrayList<>();

        for (int i = 0; i < movieTitles.length; i++) {
            book book = new book();
            book.setTitle(movieTitles[i]);
            book.setDescription(movieDescriptions[i]);
            book.setPosterImage(moviePosterImages[i]);

            movies.add(book);
        }

        return movies;
    }
}
